<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class first_controller extends Controller
{
    //
}
